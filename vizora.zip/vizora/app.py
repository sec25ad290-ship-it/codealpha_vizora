"""Vizora - Flask backend: upload, profiling, insight engine, CSV export."""
import io
import numpy as np
import pandas as pd
from flask import Flask, request, jsonify, send_file

app = Flask(__name__, static_folder="static", static_url_path="")
STORE = {"df": None}  # single-user demo store


def sample_df():
    rng = np.random.default_rng(7)
    n = 240
    months = pd.date_range("2023-01-01", periods=24, freq="MS").strftime("%Y-%m").tolist() * 10
    region = rng.choice(["North", "South", "East", "West"], n)
    product = rng.choice(["Laptop", "Phone", "Tablet", "Watch", "Earbuds"], n)
    units = rng.integers(20, 300, n)
    price = pd.Series(product).map({"Laptop": 900, "Phone": 650, "Tablet": 400, "Watch": 250, "Earbuds": 120}).values
    revenue = (units * price * rng.uniform(0.85, 1.1, n)).round(0)
    cost = (revenue * rng.uniform(0.55, 0.8, n)).round(0)
    df = pd.DataFrame({"Month": months[:n], "Region": region, "Product": product, "Units": units,
                       "Revenue": revenue, "Cost": cost, "Profit": revenue - cost,
                       "Rating": rng.normal(4.1, 0.5, n).round(1).clip(1, 5)})
    df.loc[rng.choice(n, 9, replace=False), "Rating"] = np.nan
    df.loc[5, "Revenue"] = 950000  # planted outlier
    df = pd.concat([df, df.iloc[:6]], ignore_index=True)  # planted duplicates
    return df


def dtype_name(s):
    if pd.api.types.is_numeric_dtype(s):
        return "Number"
    if pd.api.types.is_datetime64_any_dtype(s):
        return "Date"
    return "Text"


def build_insights(df):
    num = df.select_dtypes("number").columns.tolist()
    cat = [c for c in df.columns if c not in num]
    cards, story, recs = [], [], []
    for c in num[:4]:
        s = df[c].dropna()
        if s.empty:
            continue
        cards.append(dict(kind="range", icon="⬆", title=f"{c}: highest & lowest",
                          text=f"Peaks at {s.max():,.2f} (row {int(s.idxmax()) + 1}) and bottoms at {s.min():,.2f} (row {int(s.idxmin()) + 1}). The average is {s.mean():,.2f}."))
    for c in num[:3]:
        s = df[c].dropna()
        if len(s) > 8:
            slope = np.polyfit(np.arange(len(s)), s.values, 1)[0]
            pct = slope * len(s) / (abs(s.mean()) + 1e-9) * 100
            d = "rising" if pct > 5 else "falling" if pct < -5 else "steady"
            cards.append(dict(kind="trend", icon="📈", title=f"{c}: trend is {d}",
                              text=f"Across the dataset, {c} moves about {pct:+.1f}% from start to end of the rows."))
            story.append(f"{c} is {d} across the dataset ({pct:+.1f}%).")
    pairs = []
    if len(num) > 1:
        cm = df[num].corr()
        for i, a in enumerate(num):
            for b in num[i + 1:]:
                v = cm.loc[a, b]
                if pd.notna(v):
                    pairs.append((abs(v), v, a, b))
        pairs.sort(reverse=True)
        for _, v, a, b in pairs[:3]:
            strength = "very strong" if abs(v) > .8 else "strong" if abs(v) > .6 else "moderate" if abs(v) > .4 else "weak"
            way = "rise together" if v > 0 else "move in opposite directions"
            cards.append(dict(kind="corr", icon="🔗", title=f"{a} ↔ {b}: {strength}",
                              text=f"Correlation {v:+.2f}. When {a} changes, {b} tends to {way.replace('rise together', 'rise too') if v > 0 else 'fall'}."))
        if pairs:
            story.append(f"The strongest relationship is between {pairs[0][2]} and {pairs[0][3]} (r = {pairs[0][1]:+.2f}).")
            if abs(pairs[0][1]) > .6:
                recs.append(f"Use {pairs[0][2]} to forecast {pairs[0][3]}; they move together reliably.")
    tot_out = 0
    for c in num:
        s = df[c].dropna()
        if len(s) < 8:
            continue
        q1, q3 = s.quantile([.25, .75])
        iqr = q3 - q1
        n_out = int(((s < q1 - 1.5 * iqr) | (s > q3 + 1.5 * iqr)).sum())
        if n_out:
            tot_out += n_out
            cards.append(dict(kind="outlier", icon="⚠", title=f"{c}: {n_out} outlier(s)",
                              text=f"{n_out} value(s) fall outside the normal range ({q1 - 1.5 * iqr:,.1f} to {q3 + 1.5 * iqr:,.1f}). Check if they are errors or real events."))
    if tot_out:
        recs.append(f"Review the {tot_out} outlier value(s) before reporting averages; they can skew results.")
    miss = df.isna().sum()
    miss = miss[miss > 0]
    if len(miss):
        worst = miss.idxmax()
        cards.append(dict(kind="missing", icon="❓", title=f"{int(miss.sum())} missing values",
                          text=f"Most gaps are in '{worst}' ({int(miss.max())} rows, {miss.max() / len(df) * 100:.1f}%). The cleaned CSV fills numeric gaps with the median."))
        recs.append(f"Fix data collection for '{worst}' to reduce gaps.")
    else:
        cards.append(dict(kind="missing", icon="✅", title="No missing data", text="Every cell has a value. Great data quality."))
    if cat and num:
        c, m = cat[0], num[0]
        g = df.groupby(c)[m].mean().dropna().sort_values(ascending=False)
        if len(g) > 1 and g.iloc[-1] != 0:
            gap = (g.iloc[0] / g.iloc[-1] - 1) * 100
            cards.append(dict(kind="compare", icon="⚖", title=f"Best {c} for {m}",
                              text=f"'{g.index[0]}' averages {g.iloc[0]:,.1f}, which is {gap:.0f}% above '{g.index[-1]}' ({g.iloc[-1]:,.1f})."))
            story.append(f"By {c}, '{g.index[0]}' leads on {m} and '{g.index[-1]}' trails by {gap:.0f}%.")
            recs.append(f"Study what '{g.index[0]}' does well and apply it to '{g.index[-1]}'.")
    d = int(df.duplicated().sum())
    if d:
        recs.append(f"Remove {d} duplicate row(s) so totals are not double-counted.")
    if not recs:
        recs.append("Data looks healthy. Explore more chart types to find deeper patterns.")
    return cards, story, recs


def profile(df):
    cols = [dict(name=c, dtype=dtype_name(df[c]), missing=int(df[c].isna().sum()), unique=int(df[c].nunique())) for c in df.columns]
    cards, story, recs = build_insights(df)
    rows = df.head(5000).astype(object).where(df.head(5000).notna(), None).to_dict("records")
    num = df.select_dtypes("number")
    corr = None
    if num.shape[1] > 1:
        corr = dict(cols=num.columns.tolist(), z=num.corr().round(2).fillna(0).values.tolist())
    return dict(summary=dict(rows=len(df), cols=df.shape[1], missing=int(df.isna().sum().sum()), duplicates=int(df.duplicated().sum())),
                columns=cols, rows=rows, insights=cards, story=story, recs=recs, corr=corr)


@app.route("/")
def home():
    return app.send_static_file("index.html")


@app.route("/api/sample")
def api_sample():
    STORE["df"] = sample_df()
    return jsonify(profile(STORE["df"]))


@app.route("/api/upload", methods=["POST"])
def api_upload():
    f = request.files.get("file")
    if not f or not f.filename:
        return jsonify(error="Choose a CSV or Excel file first."), 400
    name = f.filename.lower()
    try:
        if name.endswith(".csv"):
            df = pd.read_csv(f)
        elif name.endswith((".xlsx", ".xls")):
            df = pd.read_excel(f)
        else:
            return jsonify(error="Unsupported file type. Upload .csv, .xlsx or .xls."), 400
    except Exception as e:
        return jsonify(error=f"Could not read the file: {e}"), 400
    if df.empty:
        return jsonify(error="The file has no rows."), 400
    STORE["df"] = df
    return jsonify(profile(df))


@app.route("/api/download/csv")
def api_csv():
    df = STORE["df"]
    if df is None:
        return jsonify(error="Load a dataset first."), 400
    out = df.drop_duplicates().copy()
    for c in out.select_dtypes("number").columns:
        out[c] = out[c].fillna(out[c].median())
    buf = io.BytesIO(out.to_csv(index=False).encode())
    return send_file(buf, mimetype="text/csv", as_attachment=True, download_name="vizora_cleaned.csv")


if __name__ == "__main__":
    app.run(debug=True, port=5000)
