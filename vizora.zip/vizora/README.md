# Vizora – Turn Data Into Stories
*See the Data. Discover the Story.*

Interactive data visualization platform: upload CSV/Excel, profile data, build 8 chart types, get auto-generated insights and a data story, and export PNG / PDF / cleaned CSV.

## Stack
Flask + pandas + NumPy (processing) · Plotly.js (charts) · jsPDF (PDF) · HTML/CSS/JS (glassmorphism UI)

## Run
```bash
pip install -r requirements.txt
python app.py        # open http://127.0.0.1:5000
```
Click **Load sample data** or upload your own file.

## Features
Upload & profiling · 8 chart types with axis/colour controls · outlier, trend, correlation & missing-data insights · "The Story Behind Your Data" · 5 portfolio projects · PNG/PDF/CSV export · responsive.

## Structure
`app.py` backend · `static/index.html`, `style.css`, `app.js` frontend.
