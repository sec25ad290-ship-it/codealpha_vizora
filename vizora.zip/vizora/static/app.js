const $=id=>document.getElementById(id);
const S={rows:[],cols:[],num:[],cat:[],data:null,counts:{s1:0,s2:0,s3:0}};
const PAL=['#22d3ee','#a78bfa','#f472b6','#34d399','#fb923c','#6366f1','#facc15','#38bdf8'];
const LY=(o={})=>Object.assign({paper_bgcolor:'rgba(0,0,0,0)',plot_bgcolor:'rgba(0,0,0,0)',font:{color:'#cbd5e1',family:'Inter'},margin:{t:50,l:55,r:20,b:60},xaxis:{gridcolor:'rgba(255,255,255,.08)'},yaxis:{gridcolor:'rgba(255,255,255,.08)'}},o);
const CFG={responsive:true,displaylogo:false};

// background floaters
['📊','📈','🥧','▂▅▇','•••','%','Σ','📉'].forEach((g,i)=>{for(let k=0;k<2;k++){const e=document.createElement('span');e.className='fl';e.textContent=g;e.style.left=Math.random()*95+'%';e.style.animationDuration=18+Math.random()*20+'s';e.style.animationDelay=-Math.random()*30+'s';$('floaters').appendChild(e)}});
$('burger').onclick=()=>$('menu').classList.toggle('open');
$('menu').onclick=()=>$('menu').classList.remove('open');

// counters
function show(id){const el=$(id),t=S.counts[id]+(+el.dataset.count);let v=+el.textContent.replace(/,/g,'')||0;const step=Math.max(1,Math.ceil((t-v)/50));const iv=setInterval(()=>{v=Math.min(t,v+step);el.textContent=v.toLocaleString();if(v>=t)clearInterval(iv)},20)}
['s1','s2','s3'].forEach(show);
function bump(k,n=1){S.counts[k]+=n;show(k)}

// load data
$('sampleBtn').onclick=async()=>{msg('Loading sample data…',1);const r=await fetch('/api/sample');ingest(await r.json());document.location.hash='#upload'};
const drop=$('drop');drop.onkeydown=e=>{if(e.key==='Enter')$('file').click()};
$('file').onchange=e=>send(e.target.files[0]);
['dragover','dragenter'].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.classList.add('over')}));
['dragleave','drop'].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.classList.remove('over')}));
drop.addEventListener('drop',e=>send(e.dataTransfer.files[0]));
async function send(f){if(!f)return;msg('Analyzing '+f.name+'…',1);const fd=new FormData();fd.append('file',f);
 try{const r=await fetch('/api/upload',{method:'POST',body:fd});const d=await r.json();if(!r.ok)return msg(d.error);ingest(d)}catch(e){msg('Server not reachable. Start it with: python app.py')}}
function msg(t,ok){const m=$('msg');m.textContent=t;m.className='msg'+(ok?' ok':'')}

function ingest(d){
 S.data=d;S.rows=d.rows;S.cols=d.columns.map(c=>c.name);S.num=d.columns.filter(c=>c.dtype==='Number').map(c=>c.name);S.cat=S.cols.filter(c=>!S.num.includes(c));
 msg(`Loaded ${d.summary.rows.toLocaleString()} rows.`,1);$('dataArea').hidden=false;
 const sm=d.summary,items=[['Rows',sm.rows],['Columns',sm.cols],['Missing values',sm.missing],['Duplicate rows',sm.duplicates]];
 $('summary').innerHTML=items.map(([k,v])=>`<div class="card sum"><b>${v.toLocaleString()}</b><span>${k}</span></div>`).join('');
 $('colTable').innerHTML='<tr><th>Column</th><th>Type</th><th>Missing</th><th>Unique</th></tr>'+d.columns.map(c=>`<tr><td>${esc(c.name)}</td><td><span class="pill">${c.dtype}</span></td><td>${c.missing}</td><td>${c.unique}</td></tr>`).join('');
 $('preview').innerHTML='<tr>'+S.cols.map(c=>`<th>${esc(c)}</th>`).join('')+'</tr>'+d.rows.slice(0,10).map(r=>'<tr>'+S.cols.map(c=>`<td>${r[c]??'<i style="color:#f472b6">null</i>'}</td>`).join('')+'</tr>').join('');
 const opts=S.cols.map(c=>`<option>${esc(c)}</option>`).join('');$('xs').innerHTML=opts;$('ys').innerHTML=opts;
 $('xs').value=S.cat[0]||S.cols[0];$('ys').value=S.num[0]||S.cols[0];
 $('insightGrid').innerHTML=d.insights.map(i=>`<div class="card ins ${i.kind}"><span>${i.icon}</span><h4>${esc(i.title)}</h4><p>${esc(i.text)}</p></div>`).join('');
 $('storyBox').innerHTML=`<h3>What we found</h3><ul>${d.story.map(s=>`<li>${esc(s)}</li>`).join('')||'<li>Not enough numeric data for trends.</li>'}</ul><h3>Data quality</h3><ul><li>${sm.missing} missing value(s) and ${sm.duplicates} duplicate row(s) in ${sm.rows.toLocaleString()} rows.</li></ul><h3>What to do next</h3><ul>${d.recs.map(s=>`<li>${esc(s)}</li>`).join('')}</ul>`;
 bump('s1');bump('s3',d.insights.length);draw();
}
const esc=s=>String(s).replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));

// charts
['ctype','xs','ys','color'].forEach(id=>$(id).onchange=()=>{draw();bump('s2')});
function agg(x,y){const m={};S.rows.forEach(r=>{const k=r[x];if(k==null||typeof r[y]!=='number')return;(m[k]??=[]).push(r[y])});
 return Object.entries(m).map(([k,v])=>[k,v.reduce((a,b)=>a+b,0)/v.length])}
function draw(){
 if(!S.rows.length)return;const t=$('ctype').value,x=$('xs').value,y=$('ys').value,c=$('color').value;
 const X=S.rows.map(r=>r[x]),Y=S.rows.map(r=>r[y]);let tr,ly=LY({title:{text:`${t}: ${y} by ${x}`,font:{size:16}}});
 const grouped=!S.num.includes(x);
 if(t==='Bar'){const a=grouped?agg(x,y):null;tr=[{type:'bar',x:a?a.map(p=>p[0]):X,y:a?a.map(p=>p[1]):Y,marker:{color:c}}];ly.yaxis.title=(grouped?'Average ':'')+y}
 else if(t==='Line'||t==='Area'){const a=grouped?agg(x,y):null;tr=[{type:'scatter',mode:'lines+markers',x:a?a.map(p=>p[0]):X,y:a?a.map(p=>p[1]):Y,line:{color:c,width:3,shape:'spline'},fill:t==='Area'?'tozeroy':'none',fillcolor:c+'33'}];ly.yaxis.title=(grouped?'Average ':'')+y}
 else if(t==='Pie'){const a=agg(x,y);tr=[{type:'pie',labels:a.map(p=>p[0]),values:a.map(p=>p[1]),hole:.45,marker:{colors:PAL}}]}
 else if(t==='Histogram'){tr=[{type:'histogram',x:S.num.includes(x)?X:Y,marker:{color:c},nbinsx:25}];ly.title.text=`Histogram of ${S.num.includes(x)?x:y}`}
 else if(t==='Scatter'){tr=[{type:'scatter',mode:'markers',x:X,y:Y,marker:{color:c,size:9,opacity:.75}}];ly.xaxis.title=x;ly.yaxis.title=y}
 else if(t==='Box'){tr=[{type:'box',x:grouped?X:undefined,y:Y,marker:{color:c},boxpoints:'outliers'}];ly.yaxis.title=y}
 else{const d=S.data.corr;if(!d){tr=[];ly.title.text='Heatmap needs 2+ numeric columns'}else{tr=[{type:'heatmap',x:d.cols,y:d.cols,z:d.z,colorscale:[[0,'#0f1a44'],[.5,'#7c3aed'],[1,c]],zmin:-1,zmax:1,text:d.z,texttemplate:'%{text}'}];ly.title.text='Correlation heatmap'}}
 Plotly.react('chart',tr,ly,CFG);
}
$('png').onclick=()=>S.rows.length?(Plotly.downloadImage('chart',{format:'png',filename:'vizora-chart',width:1200,height:700}),bump('s2')):msg('Load a dataset first.');
$('csv').onclick=e=>{if(!S.rows.length){e.preventDefault();msg('Load a dataset first.')}};
$('pdf').onclick=async()=>{
 if(!S.data)return msg('Load a dataset first.');
 const {jsPDF}=window.jspdf,doc=new jsPDF(),W=180;let y=18;
 const line=(t,sz=11,b=false)=>{doc.setFontSize(sz);doc.setFont('helvetica',b?'bold':'normal');doc.splitTextToSize(t,W).forEach(l=>{if(y>280){doc.addPage();y=18}doc.text(l,15,y);y+=sz*.5+2})};
 line('Vizora Analysis Report',20,true);line('See the Data. Discover the Story.',10);y+=4;
 const s=S.data.summary;line(`Rows: ${s.rows}   Columns: ${s.cols}   Missing: ${s.missing}   Duplicates: ${s.duplicates}`);y+=3;
 const img=await Plotly.toImage('chart',{format:'png',width:900,height:480});doc.addImage(img,'PNG',15,y,180,96);y+=104;
 line('Insights',14,true);S.data.insights.forEach(i=>line('• '+i.title+': '+i.text,10));y+=3;
 line('Story',14,true);S.data.story.forEach(i=>line('• '+i,10));y+=3;
 line('Recommendations',14,true);S.data.recs.forEach(i=>line('• '+i,10));
 doc.save('vizora-report.pdf');
};

// portfolio
let seed=11;const rnd=()=>(seed=(seed*16807)%2147483647)/2147483647;
const M=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const P=[
{t:'Sales Performance Analysis',d:'Monthly revenue vs target across regions.',k:['Q4 revenue beat target by 12%','West region grows fastest','Discounts above 20% cut margin'],f:()=>[{type:'bar',x:M,y:M.map((_,i)=>80+i*7+rnd()*20),marker:{color:'#22d3ee'},name:'Revenue'},{type:'scatter',x:M,y:M.map((_,i)=>90+i*6),line:{color:'#f472b6',dash:'dot'},name:'Target'}]},
{t:'Student Academic Performance',d:'Study hours versus exam score for 120 students.',k:['Each extra study hour adds ~4 marks','Attendance below 70% predicts low scores','Math has widest score spread'],f:()=>{const x=[...Array(80)].map(()=>1+rnd()*9);return[{type:'scatter',mode:'markers',x,y:x.map(v=>40+v*5+rnd()*14),marker:{color:'#a78bfa',size:8,opacity:.8}}]}},
{t:'Healthcare Data Analysis',d:'Patient age distribution by admission count.',k:['Admissions peak at ages 55 to 70','Winter months see 18% more visits','Average stay fell by 0.6 days'],f:()=>[{type:'histogram',x:[...Array(300)].map(()=>Math.min(95,Math.max(1,45+(rnd()+rnd()+rnd()-1.5)*45))),marker:{color:'#34d399'},nbinsx:18}]},
{t:'E-commerce Customer Insights',d:'Share of revenue by customer segment.',k:['Loyal customers give 52% of revenue','Mobile orders grew 31%','Cart abandonment is 68%'],f:()=>[{type:'pie',labels:['Loyal','Returning','New','Dormant'],values:[52,26,15,7],hole:.5,marker:{colors:PAL}}]},
{t:'Financial Performance Dashboard',d:'Cumulative profit across four quarters.',k:['Profit margin up from 14% to 19%','Operating costs stable','Q3 had the best cash flow'],f:()=>{let a=0;return[{type:'scatter',mode:'lines',fill:'tozeroy',x:M,y:M.map(()=>a+=5+rnd()*12),line:{color:'#fb923c',width:3,shape:'spline'},fillcolor:'#fb923c33'}]}}];
$('gallery').innerHTML=P.map((p,i)=>`<article class="card proj"><h3>${p.t}</h3><div class="mini" id="pm${i}"></div><p>${p.d}</p><ul>${p.k.map(k=>`<li>${k}</li>`).join('')}</ul></article>`).join('');
P.forEach((p,i)=>Plotly.newPlot('pm'+i,p.f(),LY({margin:{t:10,l:35,r:10,b:30},showlegend:false}),{displayModeBar:false,responsive:true}));
